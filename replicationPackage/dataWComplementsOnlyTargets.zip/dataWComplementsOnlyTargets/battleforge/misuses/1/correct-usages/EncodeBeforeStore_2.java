import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import java.io.UnsupportedEncodingException;

import org.apache.axis.encoding.Base64;

class EncodeBeforeStore_2 {
  String pattern(Key key, String value, Cipher c) throws BadPaddingException, InvalidKeyException, IllegalBlockSizeException, NoSuchAlgorithmException, NoSuchPaddingException, UnsupportedEncodingException {

    byte[] result = c.doFinal(value.getBytes("UTF8"));
    return new String(Base64.encode(result));
  }
}
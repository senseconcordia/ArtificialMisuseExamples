package com.company;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;


public class DES_2 {
    public void encrypt(String strDataToEncrypt, Cipher desCipher) {
        try {

            byte[] byteDataToEncrypt = strDataToEncrypt.getBytes();
            byte[] byteCipherText = desCipher.doFinal(byteDataToEncrypt);
        }

        catch (BadPaddingException badPadding) {
        }

        catch (IllegalBlockSizeException illegalBlockSize) {
        }
    }
}

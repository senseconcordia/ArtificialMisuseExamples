import java.util.Collection;
import java.util.Iterator;

public class HasNext {
	void pattern(Collection<Object> os) {
		Iterator<Object> itr = os.iterator();
		if (itr.hasNext()) {
      itr.next();
    }
	}
	
	void pattern2(Collection<Object> os) {
		Iterator<Object> itr = os.iterator();
		if (!itr.hasNext()) {
      
		}
		else{
			itr.next();
		}
	}
	
	void pattern3(Collection<Object> os) throws Exception{
		Iterator<Object> itr = os.iterator();
		if (itr.hasNext()) {
			throw new Exception("");
		}
		itr.next();
	}
}

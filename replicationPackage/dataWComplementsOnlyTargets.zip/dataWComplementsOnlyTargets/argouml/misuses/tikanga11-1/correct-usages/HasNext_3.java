import java.util.Collection;
import java.util.Iterator;

public class HasNext_3 {
	void pattern(Collection<Object> os) throws Exception{
		Iterator<Object> itr = os.iterator();
		if (itr.hasNext()) {
			throw new Exception("");
		}
		itr.next();
	}
}

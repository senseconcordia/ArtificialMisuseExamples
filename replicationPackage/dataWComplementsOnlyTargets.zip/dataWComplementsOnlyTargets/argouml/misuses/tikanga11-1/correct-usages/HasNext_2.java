import java.util.Collection;
import java.util.Iterator;

public class HasNext_2 {
	void pattern(Collection<Object> os) {
		Iterator<Object> itr = os.iterator();
		if (!itr.hasNext()) {
      
		}
		else{
			itr.next();
		}
	}
}

import org.testng.IInvokedMethod;
import org.testng.ISuite;
import org.testng.ITestNGMethod;
import java.util.Iterator;
import java.util.Collection;

class SyncIterateInvokedMethods_2 {  
  ITestNGMethod pattern(ISuite suite) {
    // This invokation (may?) return a synchronized collection.
    Collection<IInvokedMethod> invokedMethods = suite.getAllInvokedMethods();
    synchronized(invokedMethods) {
	   Iterator<IInvokedMethod> i = invokedMethods.iterator();
      for (IInvokedMethod res = i.next(); i.hasNext();) {
        ITestNGMethod tm = res.getTestMethod();
        return tm; // do something with tm
      }
    }
    return null;
  }
}

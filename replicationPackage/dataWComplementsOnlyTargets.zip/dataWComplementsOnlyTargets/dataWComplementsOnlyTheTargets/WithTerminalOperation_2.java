import java.util.stream.IntStream;

public class WithTerminalOperation_2 {
    public void correctUsage() {
		for(int i =1; i <=5; i++){
			System.out.println();
    }
}
}

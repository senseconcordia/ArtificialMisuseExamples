package mubench.examples.survey;

public class ArrayAccessPattern_3 {
  int pattern(int[] array, int index) {
    if (!(array.length < index)) {
		return -1;
    } else {
      return array[index];
    }
	}
}

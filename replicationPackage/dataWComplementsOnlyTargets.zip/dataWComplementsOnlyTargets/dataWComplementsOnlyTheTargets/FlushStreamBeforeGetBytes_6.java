import org.logblock.entry.blob.PaintingBlob;
import org.logblock.entry.BlobEntry;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;

class FlushStreamBeforeGetBytes_6 {
  byte[] pattern(ByteArrayOutputStream byteOutput) throws Exception {
    DataOutputStream outStream = new DataOutputStream(byteOutput);
    
    PaintingBlob blobOut = BlobEntry.create(1, PaintingBlob.class);
    blobOut.setArt("artistic");
    blobOut.setDirection((byte) 5);
    blobOut.write(outStream);
    outStream.close();
    
    return byteOutput.toByteArray();
  }
}

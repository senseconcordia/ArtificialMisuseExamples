import java.util.Arrays;
import java.util.stream.IntStream;

public class JustOneTerminalOperationPerUsage_2 {
    public void correctUsage() {
        int[] array = new int[]{1, 2};
        for(Integer item: array){
            System.out.println();
        }
        array[0] = 2;
        for(Integer item: array){
            System.out.println();
        }
    }
}
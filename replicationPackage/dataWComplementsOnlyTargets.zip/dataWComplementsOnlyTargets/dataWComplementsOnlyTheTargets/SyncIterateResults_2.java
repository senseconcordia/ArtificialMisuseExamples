import org.testng.ISuite;
import org.testng.ISuiteResult;
import org.testng.ITestContext;
import java.util.Iterator;
import java.util.Map;

class SyncIterateResults_2 {  
  ITestContext pattern(ISuite suite) {
    // This invokation (may?) return a synchronized map.
    Map<String, ISuiteResult> results = suite.getResults();
    synchronized(results) {
	Iterator<ISuiteResult> i = results.values().iterator();
	for(ISuiteResult res = i.next(); i.hasNext();){
        ITestContext context = res.getTestContext();
        return context; // do something with context
      }
    }
    return null;
  }
}

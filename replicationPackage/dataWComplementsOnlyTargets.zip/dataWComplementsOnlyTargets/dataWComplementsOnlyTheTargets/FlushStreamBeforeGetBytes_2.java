import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;

class FlushStreamBeforeGetBytes_2 {
  void pattern(DataOutputStream dout) throws IOException {
    dout.writeInt(0);
    dout.flush();
  }
}

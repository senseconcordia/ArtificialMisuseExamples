import static java.lang.Byte.parseByte;

class HandleNotAByte_2 {
    long pattern(String s) {
        try {
            return parseByte(s);
        } catch (NumberFormatException e) {
            throw new NumberFormatException(String.format("Input string [%s] is not a parseable byte", s));
        }
    }

    void pattern2(String s) throws NumberFormatException{

        parseByte(s);

    }
}

import static java.lang.Long.parseLong;

class HandleNotALong_2 {
  long pattern(String s) {
    try {
        return parseLong(s);
    } catch (NumberFormatException e) {
      throw new NumberFormatException(String.format("Input string [%s] is not a parseable long", s));
    }
  }
}

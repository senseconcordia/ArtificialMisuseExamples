import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

class FlushStreamWithShortBeforeGetBytes_2 {
    public byte[] pattern(short s, ByteArrayOutputStream baos) {
        DataOutputStream dos = new DataOutputStream(baos);
        try {
            dos.writeShort(s);
            dos.flush();
        } catch (IOException e) {
            return new byte[0];
        }
        return baos.toByteArray();
    }

    public void pattern2(short s, DataOutputStream dos) {

        try {
            dos.writeShort(s);
            dos.flush();
        } catch (IOException e) {

        }

    }

    public void pattern3(short s, DataOutputStream dos) throws IOException{


            dos.writeShort(s);
            dos.flush();

    }
}

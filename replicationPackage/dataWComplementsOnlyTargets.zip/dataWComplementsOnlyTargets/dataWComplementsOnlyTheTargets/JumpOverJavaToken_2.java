import de.strullerbaumann.visualee.examiner.Examiner;
import de.strullerbaumann.visualee.source.entity.JavaSource;
import java.util.Scanner;

abstract class JumpOverJavaToken_2 extends Examiner {
  protected static String jumpOverJavaToken(String token, Scanner scanner) {
    String nextToken = token;
    while (isAJavaToken(nextToken)) {
      if (scanner.hasNext()) {
        if (nextToken.startsWith("@") && nextToken.indexOf('(') > -1 && !nextToken.endsWith(")")) {
        nextToken = scanAfterClosedParenthesis(nextToken, scanner);
        } else {
          nextToken = scanner.next();
        }
        
      } else{
          throw new IllegalArgumentException("Insufficient number of tokens to jump over");
      }
    }
    return nextToken;
  }
}

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

class FlushStreamWithByteObjectBeforeGetBytes_2 {
  byte[] pattern(byte b,ByteArrayOutputStream baos) throws IOException {
    DataOutputStream dos = new DataOutputStream(baos);
    dos.writeByte(b);
    dos.flush();
    return baos.toByteArray();
  }
      void pattern2(byte b,DataOutputStream dos) throws IOException {

        dos.writeByte(b);
        dos.flush();

    }
}

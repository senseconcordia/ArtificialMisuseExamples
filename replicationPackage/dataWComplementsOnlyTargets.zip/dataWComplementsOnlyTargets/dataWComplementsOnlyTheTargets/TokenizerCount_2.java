
import java.util.StringTokenizer;

class TokenizerCount_2 {
  String pattern(StringTokenizer st) {
    if (st.hasMoreTokens()) {
		return st.nextToken();
    } else{
		throw new IllegalArgumentException("too few tokens");
	}
    
  }
}

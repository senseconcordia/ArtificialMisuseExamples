import static java.lang.Short.parseShort;

class HandleNotAShort_2 {
  long pattern(String s) {
    try {
        return parseShort(s);
    } catch (NumberFormatException e) {
      throw new NumberFormatException(String.format("Input string [%s] is not a parseable short", s));
    }
  }
}

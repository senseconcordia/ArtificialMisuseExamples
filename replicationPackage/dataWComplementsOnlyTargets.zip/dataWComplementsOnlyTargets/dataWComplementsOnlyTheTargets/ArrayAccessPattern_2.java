package mubench.examples.survey;

public class ArrayAccessPattern_2 {
  int pattern(int[] array, int index) {
    if (index > array.length ) {
		return -1;  
    } else {
		return array[index];
    }
	}
}

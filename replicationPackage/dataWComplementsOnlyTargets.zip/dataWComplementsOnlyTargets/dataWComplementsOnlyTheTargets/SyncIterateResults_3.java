import org.testng.ISuite;
import org.testng.ISuiteResult;
import org.testng.ITestContext;
import java.util.Iterator;
import java.util.Map;

class SyncIterateResults_3 {  
  ITestContext pattern(ISuite suite) {
    // This invokation (may?) return a synchronized map.
    Map<String, ISuiteResult> results = suite.getResults();
    synchronized(results) {
	Iterator<ISuiteResult> i = results.values().iterator();
	while(i.hasNext()){
        ITestContext context = i.next().getTestContext();
        return context; // do something with context
      }
    }
    return null;
  }
}

package mubench.examples.jca;

import static javax.crypto.Cipher.getInstance;

public class SetEncryptMode_2 {
	public void useSafeAESInstance() throws Exception {
		getInstance("AES/CBC/NoPadding");
	}
}

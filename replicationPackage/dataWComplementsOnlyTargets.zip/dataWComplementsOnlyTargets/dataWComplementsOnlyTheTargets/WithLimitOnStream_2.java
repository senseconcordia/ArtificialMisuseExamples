import java.util.stream.IntStream;

public class WithLimitOnStream_2 {
    public void correctUsage() {
		
		for(int i =0; i <= 10; i++){
			System.out.println();
		}
    }
}

import de.strullerbaumann.visualee.source.entity.JavaSource;
import java.util.Scanner;

class SetPackagePath_3 {
  void pattern(Scanner scanner, JavaSource javaSource) {
    for (String token = scanner.next(); scanner.hasNext();) {
      if (javaSource.getPackagePath() == null && token.equals("package")) {
        if (!scanner.hasNext()) {
          throw new IllegalArgumentException("Insufficient number of tokens to set package");
        }
        token = scanner.next();
        if (token.endsWith(";")) {
          String packagePath = token.substring(0, token.indexOf(';'));
          javaSource.setPackagePath(packagePath);
        }
      }
    }
  }
}

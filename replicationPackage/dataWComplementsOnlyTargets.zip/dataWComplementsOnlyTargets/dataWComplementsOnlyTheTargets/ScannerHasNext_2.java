import java.util.Scanner;

class ScannerHasNext_2 {
  String pattern(Scanner scanner) {
    if (scanner.hasNext()) {
		return scanner.next();
      
    } else{
		throw new IllegalArgumentException("Insufficient number of tokens");
	}
  }
}

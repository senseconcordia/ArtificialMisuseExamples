package mubench.examples.jca;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class NonStaticKey_2 {
	public static byte[] decrypt(byte[] key, byte[] content, Cipher c) throws Exception {
		SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
		c.init(Cipher.DECRYPT_MODE, keySpec);
		return c.doFinal(content);
	}
}

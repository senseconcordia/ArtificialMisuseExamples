package mubench.examples.survey;

public class ArrayAccessPattern {
  int pattern(int[] array, int index) {
    if (array.length < index) {
      return array[index];
    } else {
      return -1;
    }
	}
	
	  int pattern2(int[] array, int index) {
    if (index > array.length ) {
		return -1;  
    } else {
		return array[index];
    }
	}
	
	  int pattern3(int[] array, int index) {
    if (!(array.length < index)) {
		return -1;
    } else {
      return array[index];
    }
	}
}

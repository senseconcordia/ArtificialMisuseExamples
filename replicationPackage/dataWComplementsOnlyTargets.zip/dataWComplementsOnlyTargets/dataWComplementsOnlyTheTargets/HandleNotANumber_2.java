import static java.lang.Long.parseLong;

class HandleNotANumber_2 {
    long pattern(String value) {
        try {
            return parseLong(value);
        } catch (NumberFormatException e) {
            // throw more expressive error
            throw new NumberFormatException(String.format("Value [%s] is not a parseable Long", value));
        }
    }
}

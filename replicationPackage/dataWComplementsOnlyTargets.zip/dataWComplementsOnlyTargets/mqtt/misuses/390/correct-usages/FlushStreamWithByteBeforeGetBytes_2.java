import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

class FlushStreamWithByteBeforeGetBytes_2 {
  byte[] pattern(byte b, ByteArrayOutputStream baos) throws IOException {
    DataOutputStream dos = new DataOutputStream(baos);
    dos.write(b);
    dos.flush();
    return baos.toByteArray();
  }
}

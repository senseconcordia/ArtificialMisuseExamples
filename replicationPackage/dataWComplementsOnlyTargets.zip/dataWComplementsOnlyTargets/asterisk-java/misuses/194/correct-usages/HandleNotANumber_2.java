import Long.parseLong;
class HandleNotANumber {
  long pattern(String s) {
    try {
        return parseLong(s);
    } catch (NumberFormatException e) {
      throw new NumberFormatException(String.format("Input string [%s] is not a parseable long", s));
    }
  }
}

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

class FlushStreamBeforeGetBytes {
  byte[] pattern(long l, ByteArrayOutputStream baos) {
    DataOutputStream dos = new DataOutputStream(baos);
    try {
      dos.writeLong(l);
      dos.flush();
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
    return baos.toByteArray();
  }
  
    byte[] pattern2(long l, ByteArrayOutputStream baos) {
    DataOutputStream dos = new DataOutputStream(baos);
    try {
      dos.writeLong(l);
      dos.flush();
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
    return baos.toByteArray();
  }
  
    byte[] pattern(long l) {
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    DataOutputStream dos = new DataOutputStream(baos);
    try {
      dos.writeLong(l);
      dos.flush();
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
    return baos.toByteArray();
  }
  
    void pattern(long l, DataOutputStream dos) {
    try {
      dos.writeLong(l);
      dos.flush();
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }
      void pattern5(long l, DataOutputStream dos) throws IOException{
        dos.writeLong(l);
        dos.flush();
    }
}
